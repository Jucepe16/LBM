#ifndef __SECONDS_H
#define __SECONDS_H

double seconds();

#endif /* __SECONDS_H */
