This repository hosts the code accompanying the book

*The Lattice Boltzmann Method: Principles and Practice*  
T. Krüger, H. Kusumaatmaja, A. Kuzmin, O. Shardt, G. Silva, E.M. Viggen  
authors@lbmbook.com  
ISBN 978-3-319-44649-3 (Electronic) 978-3-319-44647-9 (Print)  
http://www.springer.com/978-3-319-44647-9  
